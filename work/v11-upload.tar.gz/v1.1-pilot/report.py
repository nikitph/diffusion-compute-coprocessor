import json,pathlib,collections,subprocess,sys,math,hashlib
root=pathlib.Path(__file__).parent;data=root/'results'
def rows(name):
 p=data/(name+'.jsonl');return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
subprocess.run([sys.executable,str(root/'analyze.py')],stdout=subprocess.DEVNULL,check=True)
a=json.loads((data/'analysis.json').read_text());g=json.loads((data/'gates.json').read_text())
full=rows('full');mid=rows('mid');linux=rows('evaluated-linux');assert full and len(linux)==101,'Experiment incomplete'
for stage in (full,mid):
 for c in {r['condition'] for r in stage}:
  ids=[r['id'] for r in stage if r['condition']==c];assert len(ids)==240 and len(set(ids))==240,(c,len(ids))
def events(r):
 if 'metrics' in r:return r['metrics'].get('events',[])
 return [e for turn in r.get('rounds',[]) for key in ('first','second') for e in turn.get(key,{}).get('events',[])]
def violations(r):
 if 'metrics' in r:return r['metrics'].get('lock_violations',0)
 return sum(turn.get(key,{}).get('lock_violations',0) for turn in r.get('rounds',[]) for key in ('first','second'))
canonical=full+mid+linux+rows('arithmetic-delay')+rows('variant-delay')+rows('hidden-delay')
safety={'lock_violations':sum(violations(r) for r in canonical),'stray_effects':sum(e['type']=='stray_effect' for r in canonical for e in r.get('events',[])),'stale_completions':sum(e['type']=='stale_completion' for r in canonical for e in r.get('events',[])),'max_remasks_per_task':max(sum(e['type']=='remask' for e in events(r)) for r in canonical)}
workspace=root.parent/'syscall-pilot/workspace';before=json.loads((root/'workspace-before-linux.json').read_text());after={str(p.relative_to(workspace)):hashlib.sha256(p.read_bytes()).hexdigest() for p in workspace.rglob('*') if p.is_file()}
safety['unexpected_workspace_changes']=[n for n in sorted(set(before)|set(after)) if n!='model_writes/native.txt' and before.get(n)!=after.get(n)]
safety['literal_write_contents_exact']=(workspace/'model_writes/native.txt').read_bytes()==b'native-written-7319'
checks=0
for r in full+mid:
 for e in r.get('injection_events',[]):
  if e.get('status')=='injected' and 'value' in e:
   truth={'+':e['a']+e['b'],'-':e['a']-e['b'],'*':e['a']*e['b']}[e['op']];assert int(e['value'])==truth;checks+=1
 for t in r.get('rounds',[]):
  q=t.get('result') or {}
  if q.get('ok') and 'operands' in q:
   x,op,y=q['operands'];assert int(q['output'])=={'+':x+y,'-':x-y,'*':x*y}[op];checks+=1
safety['kernel_outputs_independently_rechecked']=checks
(data/'final-verification.json').write_text(json.dumps(safety,indent=2))
lines=['# v1.1 results','', 'Frozen LLaDA2.2-mini; no fine-tuning. All results and source are saved locally.','', '## Expanded arithmetic set (240 tasks)','', '| Condition | Direct /120 | Downstream /120 | Fired /240 | Use (fixed / wrong-base insertions) | Regressions / right base | Direct p vs A0 |','|---|---:|---:|---:|---:|---:|---:|']
for c in ('A0','M1','A1','A2','A3','M4','A4','M5','A5','A7','A6'):
 if c not in a['full']:continue
 d=a['full'][c];p=d['direct_vs_A0']['exact_mcnemar_p'];lines.append(f"| {c} | {d['direct']['correct']} | {d['dependent']['correct']} | {d['fired']} | {d['use_numerator']}/{d['use_denominator']} | {d['regressions']}/{d['right_base']} | {p:.6g} |")
lines += ['', 'A0: no tools; A1: historical insertion; A2: conventional native calc; A3: async native calc and re-mask; A4: supplied-operand reserved slot and re-mask; A5: references; A7: protected native editing instead of re-mask; A6: post-hoc arithmetic replacement. M1/M4/M5 are sampler/prefill-matched baselines. Use and regression rates use those matched baselines where available. P-values above use A0 as explicitly requested; paired direct n=120, not 240. These exploratory p-values are not corrected for selecting the best condition.', '', '## Gates', '']
gate_records={}
for c in ('A3','A4','A5'):
 if c not in a['full']:continue
 d=a['full'][c];m=a['mid'].get(c,{});late=[r for r in rows('arithmetic-delay' if c=='A3' else 'variant-delay') if r['delay']==40 and r.get('f3',False) and (c=='A3' or r['condition']==c)]
 rate=sum(r['correct'] for r in late)/len(late) if late else None
 tests={'firing_at_least_70pct':d['firing_rate']>=.7,'use_at_least_70pct':d['use_rate'] is not None and d['use_rate']>=.7,'regressions_at_most_2pct':d['regression_rate'] is not None and d['regression_rate']<=.02,'direct_improvement_p_below_005':d['direct_vs_A0']['exact_mcnemar_p']<.05 and d['direct_vs_A0']['wrong_to_right']>d['direct_vs_A0']['right_to_wrong'],'midblock_at_least_30pct':m.get('arrivals',0)>0 and m.get('midblock',0)/m['arrivals']>=.3,'late_correct_at_least_50pct':rate is not None and rate>=.5,'remask_budget_respected':safety['max_remasks_per_task']<=2,'locks_and_effects_zero':safety['lock_violations']==0 and safety['stray_effects']==0 and not safety['unexpected_workspace_changes']}
 gate_records[c]={'tests':tests,'all_pass':all(tests.values()),'late_correct_rate':rate,'late_n':len(late)}
 lines += [f"**{c}:** "+', '.join(k+': '+('pass' if v else 'fail/not established') for k,v in tests.items())+'.','']
(data/'final-gates.json').write_text(json.dumps(gate_records,indent=2))
lines += ['A7 promotion is exploratory and does not silently replace the pre-specified best-of-A3–A5 gate. A native tool turn can still end before the answer turn starts; a masked result block is not proof that the originating call was still editable.', '', '## Block-64 intervention timing', '', '| Condition | Arrivals | Own block still masked | Masked before EOS |','|---|---:|---:|---:|']
for c,d in a['mid'].items():lines.append(f"| {c} | {d['arrivals']} | {d['midblock']} | {d['midblock_before_eos']} |")
lines += ['', '## Edit audit (36 smoke tasks)', '']
for c in ('A7','A8'):
 rs=[r for r in rows('edit-audit') if r['condition']==c];ops=[e for r in rs for e in events(r) if e['type']=='edit_ops'];lines.append(f"- {c}: {sum(r['correct'] for r in rs)}/{len(rs)} correct; {sum(e['delete'] for e in ops)} DELETE and {sum(e['split'] for e in ops)} SPLIT proposals consumed.")
lines += ['', 'A8 preserves the provisional draft without structural edits. In the original smoke audit, the two A7 improvements were one formatting repair (Answer:: NO to Answer: NO) and one correction of copied integer digits. This is not two independent arithmetic-computation gains; the kernel supplied the arithmetic result in both cases.', '', '## Linux (7 prior tasks + 20 multi-call tasks)', '', '| Condition | Prior tasks | Multi-call tasks | Total calls |','|---|---:|---:|---:|']
for c,d in a['linux'].items():lines.append(f"| {c} | {d['one']['correct']}/{d['one']['n']} | {d['multi']['correct']}/{d['multi']['n']} | {d['one']['calls']+d['multi']['calls']} |")
by={(r['condition'],r['id']):r for r in linux};onlymulti=[r['id'] for r in linux if r['condition']=='async' and r['minimum_calls']>1 and r['correct'] and not by['async_one_round',r['id']]['correct']]
lines += ['',f"Multi-call tasks completed with async four-round handling but not the one-round control: {len(onlymulti)}/20. A baseline textual DONE is not counted as a successful write.",'', '## Safety, reproducibility and retained data','', '```json',json.dumps(safety,indent=2),'```','', 'Smoke continuation decisions:','```json',json.dumps(g,indent=2),'```','', 'Reproducibility:','```json',json.dumps(a['reproducibility'],indent=2),'```','', 'The confidence repair and original prompt variants are retained separately; see README.md. Per-token attention diagnostics were unavailable under SDPA. Full raw outputs, kernel results, timings, masks, call/commit events, and control records are in results/. The A100 is retained at the user’s request ($1.79/hour GPU compute).']
(root/'RESULTS.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'report':str(root/'RESULTS.md'),'full_records':len(full),'mid_records':len(mid),'linux_records':len(linux),'safety':safety,'gates':gate_records},indent=2))
