# v1.1 checkpoint — incomplete

**Blocked:** Runpod reports insufficient balance (HTTP 402). Pod `26i6z57kcsek7x` exists but is `EXITED`; the GPU is not running. No stop or terminate API request was sent. A restart request was declined.

The 240-task expanded run, block-64 run, and 27-task Linux model run have **not started**. This checkpoint is not a completed v1.1 result.

## Completed and saved locally

- Original 36-task smoke matrix, instrumented re-mask tests, edit audit, and most delay controls.
- 45/45 canonical repeated outputs matched exactly; 5/5 legacy-baseline repeats also matched.
- Hidden-file 40-step delay: 6/6 exact with re-masking; 0/6 without. No lock violations in those controls.
- Reserved-slot smoke: 36/36 insertions; 13/18 direct and 15/18 downstream answers correct. Against its matched prefill baseline, 11/15 wrong answers became correct and 4/21 right answers regressed.
- Native-editing smoke A7: 36/36 correct. Draft-preserving, no-structural-edit A8: 34/36. A7 consumed 133 DELETE and 5 SPLIT operations. One improvement fixed output formatting and one fixed copied integer digits.
- Reference adoption: 0/18 direct cases; A5 is to be dropped under the brief’s rule.

## Native-tool contract repair pending

The native arithmetic controls exposed an instruction conflict: the system delegated large-number expressions to calc, but the kernel supports only +, -, and *. The model requested unsupported comparisons. The local source now states that comparisons must be decided by the model from the returned integer. This correction has not yet run. Earlier native-tool scores remain provisional and must not be interpreted as the final contract-corrected result.

The initial native-example variant and pre-confidence-fix cohorts are preserved separately. No weights were trained.

## Resume

1. Add funds to the Runpod account, then start the existing pod. Do not create a replacement or delete the persistent workspace. Obtain its new SSH endpoint from the service.
2. Check the retained /workspace model cache and results. Recreate the Python environment if needed; requirements.txt records versions. Prefer a persistent environment under /workspace instead of /tmp.
3. Restore the SSH reverse tunnel from remote loopback 18766 to this computer’s gateway at 18765; confirm a read-only clock call works.
4. Upload the current local pilot.py and finish_run.py. Run finish_run.py from /workspace/v1.1-pilot with HF_HOME=/workspace/hf. It preserves earlier native cohorts, reruns the corrected A2/A3 smoke and repeat cases, reruns affected controls, resumes missing slot controls, applies gates, and proceeds to expanded/mid/Linux runs.
5. Resume local result synchronization. When all stages finish, run report.py, verify counts and workspace hashes, and create the final archive.

The original brief and complete source are included. Raw results are in results/. workspace-before-linux.json records the fixture hashes before any new Linux model writes.
